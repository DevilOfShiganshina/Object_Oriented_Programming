#include <iostream>
#include "board.hpp"

// Entry point of the program
int main() {
  Board a;
  a.print_board();

  return 0;
}