// To prevent multiple inclusion during compilation
#ifndef ROADRUNNER_HPP
#define ROADRUNNER_HPP

// Including the agent.hpp, since we are inheriting that class
#include "agent.hpp"

class Roadrunner : public Agent {
private:
public:
  /**
   * \brief The constructor for the roadrunner class
   * 
   * \param Integer values for row and column
   * 
   * \return This constructor does not return anything
   */
  Roadrunner(int row, int column);
};

#endif