#include <iostream>
#include "cayote.hpp"

Cayote::Cayote(int row, int column) {
  row_position = row;
  column_position = column;
}