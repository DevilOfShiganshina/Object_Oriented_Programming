// To prevent multiple inclusion during compilation
#include <iostream>

class Agent {
protected:
  int row_position;
  int column_position;
public:

  /**
   * \brief The constructor for the agent class
   * 
   * \param This constructor does not take in any parameters
   * 
   * \return This constructor does not return anything
   */

  Agent();
};