#include <iostream> // Input / Output
#include <vector> // For the use of vectors
#include <string> // For the use of strings
#include "board.hpp" // Board class declation

//! If this constructor is invoked, a board of width and length of 20
//! will be construction.
Board::Board() {
  this->length = 20;
  this->width = 20;
  create_board();

}
//! If this constructor is invoked, a board with the user specified
//! length and width is constructed.
Board::Board(int length, int width) {
  this->length = length;
  this->width = width;
  create_board();
}

//! Deallocating the allocated memory before terminating the program
//! Gracefully.
Board::~Board() {
  delete_board();
}

//! Creates the board.
void Board::create_board() {
  for (int i = 0; i < width; i++) {
    std::vector<std::string> temp;
    for(int j = 0; j < length; j++) {
      temp.push_back(".");
    } vect.push_back(temp);
  }
}

//! Prints the board to the console window.
void Board::print_board() {
  for (int i = 0; i < width; i++) {
    for (int j = 0; j < length; j++) {
      std::cout << vect[i][j] << " ";
    } std::cout << std::endl;
  }
}

//! Deletes the board by deallocating the memory that which was
//! allocated to store the board!
void Board::delete_board() {
  vect.clear();
  vect.resize(0);
  vect.shrink_to_fit();
}