// To prevent multiple inclusion during compilation
#ifndef BOARD_HPP
#define BOARD_HPP

// Libraries that are used (Preprocessor Directives)
#include <vector> // For the use of vectors
#include <string> // For the use of strings

class Board {
private:
  int width;
  int length;
  std::vector<std::vector<std::string> > vect;

public:
  /**
   * \brief This constructor is invoked when an instance of this board
   *        is made without passing any parameters.
   * 
   * \param This constructor does not require any parameters.
   * 
   * \return This constructor does not return anything
   **/

  Board();

  /**
   * \brief This constructor is invoked when an instance of this board
   *        is made by passing the width and the length.
   * 
   * \param Two Integer values, one for width and the other for length.
   * 
   * \return This constructor does not return anything
   **/

  Board(int length, int width);

  /**
   * \brief This destructor deallocates all the memory that has been
   *        allocated before terminating the program gracefully.
   * 
   * \param This destructor does not require any parameters.
   * 
   * \return This destructor does not return anything
   **/

  ~Board();

  /**
   * \brief This function creates the board
   * 
   * \param This function does not require any parameters, though it
   *        uses the private attributes of the Board class. length_width,
   *        and the vector vect.
   * 
   * \return This function does not return anything
   **/

  void create_board();

  /**
   * \brief This function prints the board to the console window.
   * 
   * \param This function does not require any parameters, though it
   *        uses the private attributes of the Board class. length_width,
   *        and the vector vect.
   * 
   * \return This function does not return anything
   **/

  void print_board();

  void delete_board();
};

#endif