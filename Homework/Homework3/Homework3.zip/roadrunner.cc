#include <iostream>
#include "roadrunner.hpp"

Roadrunner::Roadrunner(int row, int column) {
  row_position = row;
  column_position = column;
}