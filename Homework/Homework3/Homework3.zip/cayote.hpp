// To prevent multiple inclusion during compilation
#ifndef CAYOTE_HPP
#define CAYOTE_HPP

// Including the agent.hpp, since we are inheriting that class
#include "agent.hpp"

class Cayote : public Agent {
private:
public:
  /**
   * \brief The constructor for the cayote class
   * 
   * \param Integer values for row and column
   * 
   * \return This constructor does not return anything
   */
  Cayote(int row, int column);
};

#endif